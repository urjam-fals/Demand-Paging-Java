package cscorner;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test extends JFrame {
    private JPanel panelContainer;
    private JTextField numberInputField;

    public Test() {
        setTitle("Generate Panels Based on User Input");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Input and button panel
        numberInputField = new JTextField(5);
        JButton generateButton = new JButton("Generate Panels");

        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Number of Panels:"));
        inputPanel.add(numberInputField);
        inputPanel.add(generateButton);

        // Main container for panels
        panelContainer = new JPanel();
        panelContainer.setLayout(new BoxLayout(panelContainer, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(panelContainer);

        // Add listeners
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePanels();
            }
        });

        // Add to frame
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void generatePanels() {
        panelContainer.removeAll(); // Clear previous panels

        String inputText = numberInputField.getText().trim();
        try {
            int count = Integer.parseInt(inputText);
            if (count <= 0) throw new NumberFormatException();

            for (int i = 1; i <= count; i++) {
                JPanel newPanel = new JPanel();
                newPanel.setPreferredSize(new Dimension(400, 50));
                newPanel.setBackground(new Color((int) (Math.random() * 0x1000000)));
                newPanel.add(new JLabel("Panel " + i));

                panelContainer.add(newPanel);
            }

            panelContainer.revalidate(); // Refresh layout
            panelContainer.repaint();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid positive number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Test().setVisible(true);
        });
    }
}
